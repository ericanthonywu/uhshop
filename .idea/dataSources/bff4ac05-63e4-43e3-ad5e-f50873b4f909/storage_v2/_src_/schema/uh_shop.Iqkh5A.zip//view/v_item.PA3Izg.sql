create view v_item as
select `uh_shop`.`item`.`item_id`        AS `item_id`,
       `uh_shop`.`item`.`item_code`      AS `item_code`,
       `uh_shop`.`item`.`item_name`      AS `item_name`,
       `uh_shop`.`item`.`item_category`  AS `item_category`,
       `uh_shop`.`item`.`item_price`     AS `item_price`,
       `uh_shop`.`item`.`item_stock`     AS `item_stock`,
       `uh_shop`.`item_type`.`item_type` AS `item_type`
from (`uh_shop`.`item`
       join `uh_shop`.`item_type` on ((`uh_shop`.`item`.`item_category` = `uh_shop`.`item_type`.`item_type_id`)));

