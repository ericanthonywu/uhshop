create view v_sale_detail as
select `uh_shop`.`sale_detail`.`sale_detail_id` AS `sale_detail_id`,
       `uh_shop`.`sale_detail`.`sale_invoice`   AS `sale_invoice`,
       `uh_shop`.`sale_detail`.`sale_price`     AS `sale_price`,
       `uh_shop`.`sale_detail`.`sale_quantity`  AS `sale_quantity`,
       `uh_shop`.`item`.`item_id`               AS `item_id`,
       `uh_shop`.`item`.`item_code`             AS `item_code`,
       `uh_shop`.`item`.`item_name`             AS `item_name`,
       `uh_shop`.`item`.`item_price`            AS `item_price`,
       `uh_shop`.`item`.`item_stock`            AS `item_stock`,
       `uh_shop`.`item_type`.`item_type_id`     AS `item_type_id`,
       `uh_shop`.`item_type`.`item_type`        AS `item_type`
from ((`uh_shop`.`sale_detail` join `uh_shop`.`item` on ((`uh_shop`.`sale_detail`.`sale_item` = `uh_shop`.`item`.`item_code`)))
       join `uh_shop`.`item_type` on ((`uh_shop`.`item`.`item_category` = `uh_shop`.`item_type`.`item_type_id`)));

