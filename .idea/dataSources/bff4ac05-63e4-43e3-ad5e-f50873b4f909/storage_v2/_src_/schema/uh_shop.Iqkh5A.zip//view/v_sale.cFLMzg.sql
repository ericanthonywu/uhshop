create view v_sale as
select `uh_shop`.`sale`.`sale_id`              AS `sale_id`,
       `uh_shop`.`sale`.`sale_invoice`         AS `sale_invoice`,
       `uh_shop`.`sale`.`sale_date`            AS `sale_date`,
       `uh_shop`.`sale`.`sale_total_price`     AS `sale_total_price`,
       `uh_shop`.`sale`.`sale_paid`            AS `sale_paid`,
       `uh_shop`.`sale`.`sale_status`          AS `sale_status`,
       `uh_shop`.`customer`.`customer_id`      AS `customer_id`,
       `uh_shop`.`customer`.`customer_code`    AS `customer_code`,
       `uh_shop`.`customer`.`customer_name`    AS `customer_name`,
       `uh_shop`.`customer`.`customer_address` AS `customer_address`,
       `uh_shop`.`customer`.`customer_phone`   AS `customer_phone`,
       `uh_shop`.`sale`.`sale_customer`        AS `sale_customer`,
       `uh_shop`.`sale`.`sale_image_status`    AS `sale_image_status`
from (`uh_shop`.`sale`
       join `uh_shop`.`customer` on ((`uh_shop`.`sale`.`sale_customer` = `uh_shop`.`customer`.`customer_code`)));

