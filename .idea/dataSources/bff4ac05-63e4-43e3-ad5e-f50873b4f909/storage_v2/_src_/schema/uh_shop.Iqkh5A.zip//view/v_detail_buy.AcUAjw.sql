create view v_detail_buy as
select `uh_shop`.`buy_detail`.`buy_detail_id` AS `buy_detail_id`,
       `uh_shop`.`buy_detail`.`buy_invoice`   AS `buy_invoice`,
       `uh_shop`.`buy_detail`.`buy_price`     AS `buy_price`,
       `uh_shop`.`buy_detail`.`buy_quantity`  AS `buy_quantity`,
       `uh_shop`.`item`.`item_id`             AS `item_id`,
       `uh_shop`.`item`.`item_code`           AS `item_code`,
       `uh_shop`.`item`.`item_name`           AS `item_name`,
       `uh_shop`.`item`.`item_price`          AS `item_price`,
       `uh_shop`.`item`.`item_stock`          AS `item_stock`,
       `uh_shop`.`item_type`.`item_type`      AS `item_type`
from ((`uh_shop`.`buy_detail` join `uh_shop`.`item` on ((`uh_shop`.`buy_detail`.`buy_item` = `uh_shop`.`item`.`item_code`)))
       join `uh_shop`.`item_type` on ((`uh_shop`.`item`.`item_category` = `uh_shop`.`item_type`.`item_type_id`)));

