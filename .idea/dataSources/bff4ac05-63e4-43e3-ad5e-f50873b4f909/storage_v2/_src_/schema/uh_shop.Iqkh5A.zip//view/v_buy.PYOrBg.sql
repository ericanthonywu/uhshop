create view v_buy as
select `uh_shop`.`buy`.`buy_id`                AS `buy_id`,
       `uh_shop`.`buy`.`buy_invoice`           AS `buy_invoice`,
       `uh_shop`.`buy`.`buy_date`              AS `buy_date`,
       `uh_shop`.`buy`.`buy_supplier`          AS `buy_supplier`,
       `uh_shop`.`buy`.`buy_total_price`       AS `buy_total_price`,
       `uh_shop`.`supplier`.`supplier_name`    AS `supplier_name`,
       `uh_shop`.`supplier`.`supplier_address` AS `supplier_address`,
       `uh_shop`.`supplier`.`supplier_phone`   AS `supplier_phone`
from (`uh_shop`.`buy`
       join `uh_shop`.`supplier` on ((`uh_shop`.`buy`.`buy_supplier` = `uh_shop`.`supplier`.`supplier_code`)));

